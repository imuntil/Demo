Interactive Coloring Concept
=========

A fun experimental coloring concept where a color droplet can be dragged from a palette and dropped on designated areas in a website mockup. 

[Article on Codrops](http://tympanus.net/codrops/?p=23913)

[Demo](http://tympanus.net/Development/InteractiveColoringConcept/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

Follow us: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/pages/Codrops/159107397912), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops), [Pinterest](http://www.pinterest.com/codrops/)

[© Codrops 2015](http://www.codrops.com)

Google Material Design Icons licensed under [Attribution 4.0 International](http://creativecommons.org/licenses/by/4.0/)

Gesture icons made by [Yannick](http://yanlu.de "Yannick") from [www.flaticon.com](http://www.flaticon.com "Flaticon") is licensed under [CC BY 3.0](http://creativecommons.org/licenses/by/3.0/ "Creative Commons BY 3.0")



